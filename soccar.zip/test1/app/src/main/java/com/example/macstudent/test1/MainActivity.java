package com.example.macstudent.test1;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.SoundPool;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    final static String TAG = "PONG-GAME";

    // variables for drawing
    // ---------------------
    Canvas canvas;
    PongView gameView;
    Display display;
    Point screenSize;
    int screenWidth;
    int screenHeight;

    // variables for FPS
    // -----------------
    long timeOfLastFrame;
    long fps;


    // game objects - sprites!
    // -----------------------
    Point ballPosition;
    int ballWidth;

    Point racketPosition;
    int racketWidth;
    int racketHeight;

    Point goalkeeperPosition;
    int goalkeeperWidth;
    int goalkeeperHeight;

    Point goalnetPosition;
    int goalnetWidth;
    int goalnetHeight;


    // movement variables
    // -----------------------
    boolean ballIsMovingUp;
    boolean ballIsMovingDown;

    boolean racketIsMovingUp;
    boolean racketIsMovingDown;

    boolean goalkeeperIsMovingLeft;
    boolean goalkeeperIsMovingRight;

    // game statistics (score, lives, etc)
    // -----------------------------------
    int score = 0;


    // variable for sounds
    // ------------------
    SoundPool soundPool;
    int sound1 = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        // @TODO: Do your game setup here

        // Setup this activity to use the PongView as its context
        this.gameView = new PongView(this);
        setContentView(this.gameView);

        // Setup the screen size for your game
        this.display = this.getWindowManager().getDefaultDisplay();
        this.screenSize = new Point();
        this.display.getSize(screenSize);
        this.screenHeight = screenSize.y;
        this.screenWidth = screenSize.x;

        // Setup sound, initial position of objects, score, lives, etc

        // Setup the ball
        // ---------------------

        // 1. size of ball
        this.ballWidth = this.screenWidth / 35;

        // 2. initial position of the ball on the screen
        ballPosition = new Point();
        ballPosition.x = this.screenWidth / 2;   // x position = middle
        //ballPosition.y = 1 + this.ballWidth;     // OPTION 1: y position = somewhere near the top of the screen
        ballPosition.y = this.screenHeight / 2;    // OPTION :  y position = middle of screen

        // Setup the tennis racket
        // -----------------------
        this.racketWidth = this.screenWidth / 4;    // some random width. Change it if you want.
        this.goalkeeperWidth = this.screenWidth / 6;
        this.goalnetWidth = this.screenWidth / 2;
        // -------------------------------------
        // 0a. Make the racket bigger so it's easier to work with
        // -------------------------------------
        this.racketHeight = 100;
        this.goalkeeperHeight = 100;

        this.goalnetHeight = 100;


        this.racketPosition  = new Point();
        this.racketPosition.x = this.screenWidth / 2;
        this.racketPosition.y = this.screenHeight - 400;     // somewhere near the bottom of the screen


        this.goalkeeperPosition  = new Point();
        this.goalkeeperPosition.x = this.screenWidth / 2;
        this.goalkeeperPosition.y = this.screenHeight - 1500;

        this.goalnetPosition  = new Point();
        this.goalnetPosition.x = this.screenWidth / 2;
        this.goalnetPosition.y = this.screenHeight - 2500;

        // Movement setup
        // ----------------

        // Setup initial direction of ball
        this.ballIsMovingDown = true;


        // Add Sounds to your game
        // -----------------
        this.soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        try {
            AssetManager assetManager = getAssets();
            AssetFileDescriptor descriptor = assetManager.openFd("bounce.wav");
            this.sound1 = soundPool.load(descriptor, 0);
        }
        catch(IOException e) {

        }
    }


    // Android lifecycle functions
    // ----------------------------

    @Override
    protected void onStop() {
        super.onStop();
        //@TODO: What do you want to happen when the user stops the APP?
    }

    @Override
    protected void onPause() {
        super.onPause();

        //@TODO: What should happen when the APP is paused?
    }

    @Override
    protected void onResume() {
        super.onResume();
        //@TODO: What should happen when the APP is resumed?

        // this is how you start the game
        this.gameView.resumeGame();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
        //@TODO: What should happen when user presses the BACK button on their phone?
    }

    // ----------------------------------------------------------------
    // Create an internal class that is used to manage all the drawing
    // ----------------------------------------------------------------
    class PongView extends SurfaceView implements Runnable {

        Thread gameThread = null;
        SurfaceHolder holder;
        boolean gameIsRunning;
        Paint paintbrush;

        public PongView(Context context) {
            super(context);
            this.holder = this.getHolder();
            paintbrush = new Paint();



            // @TODO: setup the ball

            // @TODO: send the ball in a random direction
        }



        @Override
        public void run() {
            while (gameIsRunning == true) {
                this.updatePositions();
                this.drawPositions();
                this.setFPS();
            }
        }

        boolean ballMovingDown = true;
        boolean ballMovingUp = false;


        // -------------------------------------
        // 0b. Add a helper function to check if ball is touching racket.
        // -------------------------------------
        public boolean ballIsTouchingRacket(Point position) {


            boolean ballInsideRacketWidth = false;
            boolean ballInsideRacketHeight = false;


            int racketLeft = racketPosition.x - (racketWidth / 2);
            int racketTop = racketPosition.y - (racketHeight / 2);


            int ballX = position.x;
            int ballY = position.y;

            if (ballX >= racketLeft && ballX <= (racketLeft + racketWidth) ) {
                ballInsideRacketWidth = true;
            }

            if (ballY >= racketTop && ballY <= (racketTop + racketHeight) ) {
                ballInsideRacketHeight = true;
            }

            if (ballInsideRacketWidth && ballInsideRacketHeight) {
                Log.d(TAG, "Ball is inside racket");
                return true;
            }
            Log.d(TAG, "Ball NOT inside racket");
            return false;
        }
        public boolean ballIsTouchinggoalkeeper(Point position) {


            boolean ballInsidegoalkeeperWidth = false;
            boolean ballInsidegoalkeeperHeight = false;


            int goalkeeperLeft = goalkeeperPosition.x - (goalkeeperWidth / 2);
            int goalkeeperTop = goalkeeperPosition.y - (goalkeeperHeight / 2);


            int ballX = position.x;
            int ballY = position.y;

            if (ballX >= goalkeeperLeft && ballX <= (goalkeeperLeft + goalkeeperWidth) ) {
                ballInsidegoalkeeperWidth = true;
            }

            if (ballY >= goalkeeperTop && ballY <= (goalkeeperTop + goalkeeperHeight) ) {
                ballInsidegoalkeeperHeight = true;
            }

            if (ballInsidegoalkeeperWidth && ballInsidegoalkeeperHeight) {
                Log.d(TAG, "Ball is inside racket");
                return true;
            }
            Log.d(TAG, "Ball NOT inside racket");
            return false;
        }

        public void updatePositions() {
            //@TODO: Put your code to update the (x,y) positions of the sprites

            // Make the ball move
            // -------------------------

            if (ballIsMovingDown == true) {
                ballPosition.y = ballPosition.y + 20;


                // Check if ball is touching racket
                // If yes, then bounce the ball

                // -------------------------------------
                // 7. Update your game logic to use the function to check if ball is touching racket
                // -------------------------------------

                if (ballIsTouchingRacket(ballPosition) == true)  {
                    // change direction of ball
                    ballIsMovingDown = false;
                    ballIsMovingUp = true;


                    // play a "bounce" sound
                    soundPool.play(sound1, 1,1,0,0,1);

                }
            }

            if (ballIsMovingUp == true) {
                ballPosition.y = ballPosition.y - 20;
                // If the new ball position is at top of screen,
                // then switch directions again
                if (ballPosition.y <= 0) {
                    ballIsMovingDown = false;
                    ballIsMovingUp = false;


                    // play a "bounce" sound
                    soundPool.play(sound1, 1,1,0,0,1);
                }

                if (ballIsTouchinggoalkeeper(ballPosition) == true)  {
                    // change direction of ball
                    ballIsMovingUp = false;
                    ballIsMovingDown = true;

                    // increase the score
                    score = score + 1;

                    if (score == 5 ) {

                     String message1 = "You win";



                    }


                    // play a "bounce" sound
                    soundPool.play(sound1, 1,1,0,0,1);

                }

            }

            // Make racket move
            // -------------------------

            if (racketIsMovingDown == true) {
                racketPosition.y = racketPosition.y + 10;
            }

            if (racketIsMovingUp == true) {
                racketPosition.y = racketPosition.y - 10;
            }

            if (goalkeeperIsMovingLeft == true) {
                goalkeeperPosition.x = goalkeeperPosition.x + 10;
            }

            if (goalkeeperIsMovingRight == true) {
                goalkeeperPosition.x = goalkeeperPosition.x - 10;
            }
        }

        public void drawPositions() {
            // @TODO:  Put code to actually draw the sprites on the screen

            // required nonsense
            if (this.holder.getSurface().isValid()) {
                // prevent other apps from modifying the canvas
                canvas = this.holder.lockCanvas();

                // background color
                canvas.drawColor(Color.BLACK);

                // color of objects
                paintbrush.setColor(Color.argb(255, 255, 255, 255));

                // size of font
                paintbrush.setTextSize(45);

                canvas.drawRect(250,20,850,50,paintbrush);

                // code to draw the ball
                // -----------------------

                // the ball is a square (you could use a circle)
                // For squares/rectangles, give coordinates of all 4 corners

                int left = ballPosition.x;
                int top = ballPosition.y;
                int right = ballPosition.x + ballWidth;
                int bottom = ballPosition.y + ballWidth;
                canvas.drawRect(left, top, right, bottom, paintbrush);







                // code to draw the ball
                // -----------------------

                // you could also use a line
                int rktLeft = racketPosition.x - (racketWidth / 2);
                int rktTop = racketPosition.y - (racketHeight / 2);
                int rktRight = racketPosition.x + (racketWidth / 2);
                int rktBottom = racketPosition.y + (racketHeight / 2);

                canvas.drawRect(rktLeft, rktTop, rktRight, rktBottom, paintbrush);

                int gkLeft = goalkeeperPosition.x - (goalkeeperWidth / 2);
                int gkTop = goalkeeperPosition.y - (goalkeeperHeight / 2);
                int gkRight = goalkeeperPosition.x + (goalkeeperWidth / 2);
                int gkBottom = goalkeeperPosition.y + (goalkeeperHeight / 2);

                canvas.drawRect(gkLeft, gkTop, gkRight, gkBottom, paintbrush);


                // code to draw game statistics (scores, lives, etc)
                // ----------------------------------------------



                String message = "Your score: " + score;
                canvas.drawText(message, 10, 100, paintbrush);

                if (score == 5) {
                    String message2 = "You Win  (*_*) ";

                    canvas.drawText(message2, 30, 300, paintbrush);

                    gameIsRunning = false;

                }

                if (ballPosition.y <= 0) {

                    String message1 = "You Lose ";

                    canvas.drawText(message1, 20, 200, paintbrush);


                }

                // we are done drawing, so we can "unlock" the canvas.
                // other apps can access it now
                this.holder.unlockCanvasAndPost(canvas);
            }
        }

        public void setFPS() {
            //@TODO: Implement code to deal with FPS
            // Generally, you want around 60 frames per second.

            long timeOfCurrentFrame = (System.currentTimeMillis()  - timeOfLastFrame);
            long timeToSleep = 15 - timeOfCurrentFrame;
            if (timeOfCurrentFrame > 0) {
                fps = (int) (1000/ timeOfCurrentFrame);
            }
            if (timeToSleep > 0) {
                try {
                    gameThread.sleep(timeToSleep);

                }
                catch (InterruptedException e) {
                    //@TODO: Optional - put some error messaging here
                }
            }
            timeOfLastFrame = System.currentTimeMillis();
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            //@TODO: Add code to deal with user input (user touching the screen)


            // I have no idea what this means.
            // Mandatory nonsense to detect when person taps the screen
            switch (event.getAction() & MotionEvent.ACTION_MASK) {
                case MotionEvent.ACTION_DOWN:
                    // press finger down
                    Log.d(TAG, "The person tapped: (" + event.getX() + "," + event.getY() + ")");


                    // if left side, move racket up
                    double middleOfScreen = screenWidth / 2;
                    if (event.getX() <= middleOfScreen) {
                        racketIsMovingUp = true;
                        racketIsMovingDown = false;

                        goalkeeperIsMovingLeft = true;
                        goalkeeperIsMovingRight = false;
                    }
                    else {
                        // if right side, move racket down
                        racketIsMovingDown = true;
                        racketIsMovingUp = false;

                        goalkeeperIsMovingRight = true;
                        goalkeeperIsMovingLeft = false;

                    }
                    break;

                case MotionEvent.ACTION_UP:
                    // person lifted their finger
                    racketIsMovingDown = false;
                    racketIsMovingUp = false;

                    goalkeeperIsMovingRight = false;
                    goalkeeperIsMovingLeft = false;

                    break;
            }

            return true;
        }


        public void pauseGame() {
            //@TODO: Code for when the user pauses the game
        }

        public void resumeGame() {
            //@TODO: Code for when the the game is "unpaused" (or user is playing again)

            // this is how you "start" the game loop
            gameIsRunning = true;
            this.gameThread = new Thread(this);
            this.gameThread.start();
        }

    } // --- End of PongView class
}
