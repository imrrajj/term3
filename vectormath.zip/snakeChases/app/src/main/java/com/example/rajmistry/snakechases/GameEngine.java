package com.example.rajmistry.snakechases;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameEngine extends SurfaceView implements Runnable {
    private final String TAG = "VECTOR-MATH";

    // game thread variables
    private Thread gameThread = null;
    private volatile boolean gameIsRunning;

    // drawing variables
    private Canvas canvas;
    private Paint paintbrush;
    private SurfaceHolder holder;

    // Screen resolution varaibles
    private int screenWidth;
    private int screenHeight;

    // set up your objects
    Sprite bullet;
    Sprite square;
    final int SIZE = 10;


    // Let's make an array of bullets
    List<Sprite> bullets = new ArrayList<Sprite>();


    public GameEngine(Context context, int screenW, int screenH) {
        super(context);

        // intialize the drawing variables
        this.holder = this.getHolder();
        this.paintbrush = new Paint();

        // set screen height and width
        this.screenWidth = screenW;
        this.screenHeight = screenH;


        // create an array of bullets - add 10 bullets to the screen
        for (int i = 0; i < 10; i++) {
            Random r = new Random();
            int randomXPos = r.nextInt(this.screenWidth) + 1;
            int randomYPos = r.nextInt(this.screenHeight) + 1;
            Sprite b = new Sprite(getContext(),randomXPos, randomYPos, SIZE, SIZE);
            bullets.add(b);
        }

        // create a 10x10 square located at (1000, 100)
        square = new Sprite(getContext(), 1000,  100, SIZE, SIZE);


    }

    @Override
    public void run() {
        // @TODO: Put game loop in here
        while (gameIsRunning == true) {
            updateGame();
            drawGame();
            controlFPS();
        }
    }

    boolean squareIsMovingDown = true;
    final int SQUARESPEED = 30;

    // Game Loop methods
    public void updateGame() {
        Random r = new Random();
        int randomXPos = r.nextInt(this.screenWidth) + 1;
        int randomYPos = r.nextInt(this.screenHeight) + 1;
        square.x = randomXPos;
        square.y = randomYPos;



        // @TODO:  Move the square
        // --------------------------
        if (squareIsMovingDown == true) {
            square.y = square.y + SQUARESPEED;
            // if square reaches bottom of screen, switch directions
            if (square.y >= this.screenHeight) {
                squareIsMovingDown = false;
            }
        }
        else {
            square.y = square.y - SQUARESPEED;
            // if square reaches top of screen, switch directions
            if (square.y <= 0) {
                squareIsMovingDown = true;
            }
        }


        for (int i = 0; i < bullets.size(); i++) {
            // 0. Get the bullet out of the array
            Sprite bull = bullets.get(i);


            // @TODO:  Move the square
            // 1. calculate distance between bullet and square
            double a = (square.x - bullet.x);
            double b = (square.y - bullet.y);
            double distance = Math.sqrt((a * a) + (b * b));

            // 2. calculate the "rate" to move
            double xn = (a / distance);
            double yn = (b / distance);

            // 3. move the bullet
            bullet.x = bullet.x + (int) (xn * 15);
            bullet.y = bullet.y + (int) (yn * 15);

            Log.d(TAG, "New bullet (x,y): (" + bullet.x + "," + bullet.y + ")");
        }
    }

    public void drawGame() {
        if (holder.getSurface().isValid()) {



            // @TODO:  Draw a stationary object on the screen (purple square)
            paintbrush.setStyle(Paint.Style.STROKE);
            paintbrush.setStrokeWidth(10);
            paintbrush.setColor(Color.MAGENTA);
            canvas.drawRect(square.x, square.y,square.x+SIZE, square.y+SIZE, paintbrush);

            // @TODO:  Draw your bullet (black square)
            paintbrush.setColor(Color.BLACK);
            canvas.drawRect(bullet.x,bullet.y,bullet.x+SIZE,bullet.y+SIZE, paintbrush);



            // initialize the canvas
            canvas = holder.lockCanvas();
            // --------------------------------
            // @TODO: put your drawing code in this section

            // set the game's background color
            canvas.drawColor(Color.argb(255,255,255,255));

            for (int i = 0; i < bullets.size(); i++) {
                Sprite b = bullets.get(i);
                canvas.drawRect(b.x, b.y, b.x + SIZE, b.y + SIZE, paintbrush);
            }


            // --------------------------------
            holder.unlockCanvasAndPost(canvas);
        }

    }

    public void controlFPS() {
        try {
            gameThread.sleep(17);
        }
        catch (InterruptedException e) {

        }
    }


    // Deal with user input


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_UP:
                square.x = (int) event.getX();
                square.y = (int) event.getY();

                Log.d("PUSH", "PERSON CLICKED AT: (" + event.getX() + "," + event.getY() + ")");



                break;
            case MotionEvent.ACTION_DOWN:

                break;
        }
        return true;
    }

    // Game status - pause & resume
    public void pauseGame() {
        gameIsRunning = false;
        try {
            gameThread.join();
        }
        catch (InterruptedException e) {

        }
    }
    public void  resumeGame() {
        gameIsRunning = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

}
