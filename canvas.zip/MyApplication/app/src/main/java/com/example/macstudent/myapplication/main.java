package com.example.macstudent.myapplication;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView ivFrame = (ImageView) findViewById(R.id.imageView2);
        Bitmap b = Bitmap.createBitmap(300,500, Bitmap.Config.ARGB_8888);
        ivFrame.setImageBitmap(b);

        Canvas canvas = new Canvas(b);
         Paint paintbrush = new Paint();
        Paint paintbrushEyes = new Paint();

        canvas.drawColor(Color.RED);
        paintbrush.setColor(Color.argb(255,255,255,255));
        paintbrushEyes.setColor(Color.argb(255,105,180,220));
        paintbrush.setStrokeWidth(5);
        paintbrushEyes.setStrokeWidth(5);

//        canvas.drawCircle(100,150,50,paintbrush);
//        canvas.drawText("Hello, This is a game",0,400,paintbrush);
//        canvas.drawLine(10,50,200,59,paintbrush);
//        canvas.drawRect(10,110,120,120,paintbrush);

        canvas.drawCircle(130,150,50,paintbrush);       //face
        canvas.drawRect(60,300,195,200,paintbrush);        // body

        canvas.drawLine(60,200,20,300,paintbrush);   //Left hand
        canvas.drawLine(195,200,240,300,paintbrush);   //Right hand

        canvas.drawLine(195,400,195,300,paintbrush);  // right leg
        canvas.drawLine(60,400,60,300,paintbrush);   // left leg

        canvas.drawCircle(110,140,5,paintbrushEyes);     //left eye
        canvas.drawCircle(150,140,5,paintbrushEyes);     // right eye
        canvas.drawCircle(130,175,10,paintbrushEyes);    // mouth
        canvas.drawLine(130,150,130,160,paintbrushEyes); //nose

    }
}
